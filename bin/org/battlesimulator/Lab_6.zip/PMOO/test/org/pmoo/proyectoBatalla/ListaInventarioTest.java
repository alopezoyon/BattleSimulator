package org.pmoo.proyectoBatalla;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ListaInventarioTest {
	
	private ListaInventario lista;
	private ObjetoAtaque objA1;
	private ObjetoAtaque objA2;
	private ObjetoCuracion objC1;
	private ObjetoCuracion objC2;
	private ObjetoDefensa objD1;
	private ObjetoDefensa objD2;
	
	
	@Before
	public void setUp() throws Exception {
		lista = new ListaInventario();
		objA1 = new ObjetoAtaque (1,"Hacha1",20);
		objA2 = new ObjetoAtaque (11,"Hacha2",15);
		objC1 = new ObjetoCuracion (2,"Venda1",5);
		objC2 = new ObjetoCuracion (22,"Venda2",5);
		objD1 = new ObjetoDefensa (3,"Escudo1",10);
		objD2 = new ObjetoDefensa (33,"Escudo2",15);
	}

	@After
	public void tearDown() throws Exception {
		lista = null;
		objA1 = null;
		objA2 = null;
		objC1 = null;
		objC2 = null;
		objD1 = null;
		objD2 = null;
	}

	@Test
	public void testListaInventario() {
		assertNotNull(lista);
	}

	@Test
	public void testAnadirObjeto() {
		
		this.lista.anadirObjeto(objA1);
		assertTrue(this.lista.estaObjetoConId(1));
		
		this.lista.anadirObjeto(objC1);
		assertTrue(this.lista.estaObjetoConId(2));

		this.lista.anadirObjeto(objD1);
		assertTrue(this.lista.estaObjetoConId(3));
		
		assertNotNull(lista);
	}

	@Test
	public void testEstaObjetoConId() {
		
		this.lista.anadirObjeto(objA1);
		this.lista.anadirObjeto(objC1);
		this.lista.anadirObjeto(objD1);
		
		assertTrue(this.lista.estaObjetoConId(1));
		assertTrue(this.lista.estaObjetoConId(2));
		assertFalse(this.lista.estaObjetoConId(4));
		assertFalse(this.lista.estaObjetoConId(5));
	}

	@Test
	public void testObtenerDanoObjetos() {
		
		this.lista.anadirObjeto(objA1);
		this.lista.anadirObjeto(objA2);
		
		assertEquals(this.lista.obtenerDanoObjetos(), 35);
		
		this.lista.anadirObjeto(objC1);
		assertEquals(this.lista.obtenerDanoObjetos(), 35);

	}

	@Test
	public void testObtenerProteccionObjetos() {
		this.lista.anadirObjeto(objD1);
		this.lista.anadirObjeto(objD2);
		
		assertEquals(this.lista.obtenerProteccionObjetos(), 25);
		
		this.lista.anadirObjeto(objC1);
		assertEquals(this.lista.obtenerProteccionObjetos(), 25);
	}

	@Test
	public void testObtenerCuracionPrimerObjeto() {
		this.lista.anadirObjeto(objC1);
		this.lista.anadirObjeto(objC2);
		
		assertEquals(this.lista.obtenerCuracionPrimerObjeto(), 10);
		
		this.lista.anadirObjeto(objA1);
		assertEquals(this.lista.obtenerCuracionPrimerObjeto(), 10);
	}

	@Test
	public void testObtenerCuracionObjetoConId() {
	}

	@Test
	public void testImprimirInventario() {
		this.lista.anadirObjeto(objA1);
		this.lista.anadirObjeto(objC1);
		this.lista.anadirObjeto(objD1);
		this.lista.imprimirInventario();
	}

	@Test
	public void testImprimirOpcionesCuracion() {
		//Imprime solo los datos de los objetos de curaci�n
		this.lista.anadirObjeto(objC1);
		this.lista.anadirObjeto(objC2);
		this.lista.anadirObjeto(objA1);
		this.lista.imprimirOpcionesCuracion();
	}

}
