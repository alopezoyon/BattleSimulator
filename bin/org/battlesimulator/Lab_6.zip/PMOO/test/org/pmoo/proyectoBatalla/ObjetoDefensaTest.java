package org.pmoo.proyectoBatalla;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ObjetoDefensaTest {
	
	private ObjetoDefensa obj1;
	private ObjetoDefensa obj2;
	private ObjetoDefensa obj3;

	@Before
	public void setUp() throws Exception {
		this.obj1 = new ObjetoDefensa (1,"Escudo1", 10);
		this.obj2 = new ObjetoDefensa (2,"Escudo2", 20);
		this.obj3 = new ObjetoDefensa (3,"Escudo3", -8);
	}

	@After
	public void tearDown() throws Exception {
		this.obj1 = null;
		this.obj2 = null;
		this.obj3 = null;
	}

	@Test
	public void testGetDefensa() {
		assertEquals(this.obj1.getDefensa(), 10);
		assertEquals(this.obj2.getDefensa(), 20);
		assertEquals(this.obj3.getDefensa(), 0);
	}

	@Test
	public void testImprimirObjeto() {
		this.obj1.imprimirObjeto();
		this.obj2.imprimirObjeto();
		this.obj3.imprimirObjeto();
	}

}
