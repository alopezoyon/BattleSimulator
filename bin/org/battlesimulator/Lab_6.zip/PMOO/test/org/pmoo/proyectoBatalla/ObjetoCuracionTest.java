package org.pmoo.proyectoBatalla;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ObjetoCuracionTest {
	
	private ObjetoCuracion obj1;
	private ObjetoCuracion obj2;
	private ObjetoCuracion obj3;
	
	@Before
	public void setUp() throws Exception {
		this.obj1 = new ObjetoCuracion (1, "Venda1", 10);
		this.obj2 = new ObjetoCuracion (2, "Venda2", 20);
		this.obj3 = new ObjetoCuracion (3, "Venda3", -5);
	}

	@After
	public void tearDown() throws Exception {
		this.obj1 = null;
		this.obj2 = null;
		this.obj3 = null;
	}

	@Test
	public void testGetCuracion() {
		assertEquals(this.obj1.getCuracion(), 10);
		assertEquals(this.obj2.getCuracion(), 20);
		assertEquals(this.obj3.getCuracion(), 0);
	}

	@Test
	public void testImprimirObjeto() {
		this.obj1.imprimirObjeto();
		this.obj2.imprimirObjeto();
		this.obj3.imprimirObjeto();
	}
	
	@Test
	public void testImprimirUso() {
		this.obj1.imprimirUso();
		this.obj2.imprimirUso();
		this.obj3.imprimirUso();
	}


}
