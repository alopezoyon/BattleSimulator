package org.pmoo.proyectoBatalla;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ObjetoAtaqueTest {
	
	private ObjetoAtaque obj1;
	private ObjetoAtaque obj2;
	private ObjetoAtaque obj3;

	@Before
	public void setUp() throws Exception {
		this.obj1 = new ObjetoAtaque (1, "Hacha1",10);
		this.obj2 = new ObjetoAtaque (2, "Hacha2", 20);
		this.obj3 = new ObjetoAtaque (3, "Hacha3", -2);
	}

	@After
	public void tearDown() throws Exception {
		this.obj1 = null;
		this.obj2 = null;
		this.obj3 = null;
	}

	@Test
	public void testGetAtaque() {
		assertEquals(this.obj1.getAtaque(), 10);
		assertEquals(this.obj2.getAtaque(), 20);
		assertEquals(this.obj3.getAtaque(), 0);
	}

	@Test
	public void testImprimirObjeto() {
		this.obj1.imprimirObjeto();
		this.obj2.imprimirObjeto();
		this.obj3.imprimirObjeto();
	}

}
