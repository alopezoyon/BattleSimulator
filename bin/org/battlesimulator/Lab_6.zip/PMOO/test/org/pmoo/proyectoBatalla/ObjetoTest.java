package org.pmoo.proyectoBatalla;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ObjetoTest {
	
	private Objeto obj1;
	private Objeto obj2;
	private Objeto obj3;
	private Objeto obj4;

	@Before
	public void setUp() throws Exception {
		this.obj1 = new ObjetoAtaque (1, "Hacha", 20);
		this.obj2 = new ObjetoCuracion(2, "Venda", 5);
		this.obj3 = new ObjetoDefensa (3, "Escudo1", 10);
		this.obj4 = new ObjetoDefensa (4, "Escudo2", -5);
	}

	@After
	public void tearDown() throws Exception {
		this.obj1 = null;
		this.obj2 = null;
		this.obj3 = null;
		this.obj4 = null;
	}

	@Test
	public void testGetNombre() {
		assertEquals(this.obj1.getNombre(), "Hacha");
		assertEquals(this.obj2.getNombre(), "Venda");
		assertEquals(this.obj3.getNombre(), "Escudo1");
		assertEquals(this.obj4.getNombre(), "Escudo2");
	}
	
	@Test
	public void testGetId() {
		assertEquals(this.obj1.getId(), 1);
		assertEquals(this.obj2.getId(), 2);
		assertEquals(this.obj3.getId(), 3);
		assertEquals(this.obj4.getId(), 4);
	}

	@Test
	public void testTieneEsteId() {
		assertTrue(this.obj1.tieneEsteId(1));
		assertTrue(this.obj3.tieneEsteId(3));
		assertFalse(this.obj3.tieneEsteId(1));
		assertFalse(this.obj4.tieneEsteId(3));
	}
	
	
	@Test
	public void testImprimirObjeto() {
		this.obj1.imprimirObjeto();
		this.obj2.imprimirObjeto();
		this.obj3.imprimirObjeto();
		this.obj4.imprimirObjeto();
	}

}
